package com.ecycle.AccountActivity
import android.content.Intent

import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*


class LoginActivity : AppCompatActivity() {

   private lateinit var  mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        mAuth = FirebaseAuth.getInstance()

        val registerButton = findViewById<Button>(R.id.registerButton)
        val fieldEmail = findViewById<EditText>(R.id.fieldEmail)
        val fieldPassword = findViewById<EditText>(R.id.fieldPassword)
        val forgotPassButton = findViewById<TextView>(R.id.forgotPassButton)




        forgotPassButton.setOnClickListener {
            startActivity(Intent(this@LoginActivity, ResetPassActivity::class.java))


        }


        signInButton.setOnClickListener{

            val email = fieldEmail.text.toString().trim()
            val password = fieldPassword.text.toString().trim()
            if (email.isEmpty()) {
                fieldEmail.error = "Email is required"
                fieldEmail.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                fieldEmail.error = "Please enter a valid email"
                fieldEmail.requestFocus()
                return@setOnClickListener
            }


            if (password.isEmpty()) {
                fieldPassword.error = "Password is required"
                fieldPassword.requestFocus()
                return@setOnClickListener
            }


            loginUser(email, password)
        }




        registerButton.setOnClickListener {
            startActivity(Intent(this@LoginActivity, RegisterActivity::class.java))


        }


    }

    private fun loginUser(email: String, password: String) {
        progressBar.visibility = View.VISIBLE
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this){ task ->
                    progressBar.visibility = View.INVISIBLE
                    if(task.isSuccessful){
                        login()
                    }
                    else{
                        task.exception?.message?.let{
                            toast(it)
                        }
                    }
                }

    }

    override fun onStart() {
        super.onStart()

        mAuth.currentUser?.let{
            login()
        }
    }
}

