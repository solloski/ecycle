package com.ecycle.AccountActivity

import android.content.Intent

import android.os.Bundle
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


import kotlinx.android.synthetic.main.activity_register.*




open class RegisterActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)


        val registerBack = findViewById<Button>(R.id.registerBack)
        val registerNext = findViewById<Button>(R.id.registerNext)
        val emailRegister = findViewById<EditText>(R.id.emailRegister)
        val passwordRegister = findViewById<EditText>(R.id.passwordRegister)
        val radioButtonBuyer = findViewById<RadioButton>(R.id.radioButtonBuyer)
        val radioButtonSeller = findViewById<RadioButton>(R.id.radioButtonSeller)
        val radioButtonRole = findViewById<RadioGroup>(R.id.radioButtonRole)


        registerBack.setOnClickListener {
            startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))


        }






        registerNext.setOnClickListener {


            val email = emailRegister.text.toString().trim()
            val password = passwordRegister.text.toString().trim { it <= ' ' }
            val cpassword = passwordRegisterConfirm.text.toString().trim { it <= ' ' }


            if (email.isEmpty()) {
                emailRegister.error = "Email is required"
                emailRegister.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailRegister.error = "Please enter a valid email"
                emailRegister.requestFocus()
                return@setOnClickListener
            }


            if (password.isEmpty()) {
                passwordRegister.error = "Password is required"
                passwordRegister.requestFocus()
                return@setOnClickListener
            }

            if (password.length < 6) {
                passwordRegister.error = "Minimum 6 characters"
                passwordRegister.requestFocus()
                return@setOnClickListener
            }

            if (cpassword != password) {
                passwordRegisterConfirm.error = "Retype the password"
                passwordRegisterConfirm.requestFocus()
                return@setOnClickListener
            }

            if (radioButtonRole!!.checkedRadioButtonId == -1) {
                Toast.makeText(applicationContext, "Please select an option", Toast.LENGTH_SHORT).show()
                textView3.requestFocus()
                return@setOnClickListener
            }

            if (radioButtonBuyer.isChecked) {
                val intent = Intent(this@RegisterActivity, RegisterBuyerActivity::class.java)
                intent.putExtra("Email", email)
                intent.putExtra("Password", password)
                        startActivity(intent)
                    }
            if (radioButtonSeller.isChecked){
                val intent = Intent(this@RegisterActivity, RegisterSellerActivity::class.java)
                intent.putExtra("Email", email)
                intent.putExtra("Password", password)
                startActivity(intent)
                    }
            }

    }

}
