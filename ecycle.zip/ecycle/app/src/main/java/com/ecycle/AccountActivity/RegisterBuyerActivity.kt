package com.ecycle.AccountActivity
import android.content.Intent

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.ecycle.AccountActivity.MainActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore


import kotlinx.android.synthetic.main.activity_register.*

import kotlinx.android.synthetic.main.activity_register_buyer.*
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.HashMap
import com.google.firebase.auth.FirebaseUser

import android.R.attr.name
import android.R.attr.password
import android.R.attr.name
import android.R.attr.password
import com.ecycle.ProfileFragment


class RegisterBuyerActivity : AppCompatActivity() {



    private lateinit var database: DatabaseReference
    private lateinit var mAuth : FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_buyer)






        val companyField = findViewById<EditText>(R.id.companyField)
        val repField = findViewById<EditText>(R.id.repField)
        val cityField = findViewById<EditText>(R.id.cityField)
        val addressField = findViewById<EditText>(R.id.addressField)

        mAuth = FirebaseAuth.getInstance()


        registerBuyerBack.setOnClickListener {
            startActivity(Intent(this@RegisterBuyerActivity, RegisterActivity::class.java))


        }


        registerBuyerNext.setOnClickListener{

            val company = companyField.text.toString().trim()
            val rep = repField.text.toString().trim()
            val city = cityField.text.toString().trim()
            val address = addressField.text.toString().trim()

            if (company.isEmpty() || rep.isEmpty() || city.isEmpty() || address.isEmpty()) {
                Toast.makeText(applicationContext, "Please complete all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val email=intent.getStringExtra("Email")
            val password=intent.getStringExtra("Password")





            registerUser(email, password)




        }

    }

    private fun registerUser(email: String, password: String) {


        progressBar.visibility = View.VISIBLE
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this){task ->

                    if (task.isSuccessful){
                        progressBar.visibility = View.INVISIBLE
                        val intent = Intent(this@RegisterBuyerActivity, ProfileFragment::class.java).apply{
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        }
                        startActivity(intent)


                        val user = FirebaseAuth.getInstance().currentUser!!.uid
                        val currentuserdb = FirebaseDatabase.getInstance().reference.child("Users").child(user)

                        val company = companyField.text.toString().trim()
                        val rep = repField.text.toString().trim()
                        val city = cityField.text.toString().trim()
                        val address = addressField.text.toString().trim()


                        val newPost = HashMap<String,String>()
                        newPost[company] = "company name"
                        newPost[rep] = "representative name"
                        newPost[city] = "city"
                        newPost[address] = "address"


                        currentuserdb.setValue(newPost)

                    }
                    else
                        task.exception?.message?.let {
                            toast(it)
                        }
                }
    }





    override fun onStart() {
        super.onStart()

        mAuth.currentUser?.let{
            login()
        }
    }

}