package com.ecycle.AccountActivity


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_register_buyer.*
import kotlinx.android.synthetic.main.activity_register_seller.*
import java.util.HashMap


class RegisterSellerActivity : AppCompatActivity() {


    private lateinit var database: DatabaseReference
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_buyer)


        val firstName = findViewById<EditText>(R.id.firstName)
        val lastName = findViewById<EditText>(R.id.lastName)
        val cityFieldS = findViewById<EditText>(R.id.cityFieldS)
        val addressFieldS = findViewById<EditText>(R.id.addressFieldS)
        val phoneField = findViewById<EditText>(R.id.phoneField)

        mAuth = FirebaseAuth.getInstance()


        registerSellerBack.setOnClickListener {
            startActivity(Intent(this@RegisterSellerActivity, RegisterActivity::class.java))


        }

        registerBuyerNext.setOnClickListener{

            val firstname = firstName.text.toString().trim()
            val lastname = lastName.text.toString().trim()
            val city = cityFieldS.text.toString().trim()
            val address = addressFieldS.text.toString().trim()
            val phone = phoneField.text.toString().trim()

            if (firstname.isEmpty() || lastname.isEmpty() || city.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                Toast.makeText(applicationContext, "Please complete all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val email=intent.getStringExtra("Email")
            val password=intent.getStringExtra("Password")





            registerUser(email, password)




        }


    }

    private fun registerUser(email: String, password: String) {


        progressBar2.visibility = View.VISIBLE
        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this){task ->

                if (task.isSuccessful){
                    progressBar2.visibility = View.INVISIBLE
                    val intent = Intent(this@RegisterSellerActivity, MainActivity::class.java).apply{
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)


                   /* val user = FirebaseAuth.getInstance().currentUser!!.uid
                    val currentuserdb = FirebaseDatabase.getInstance().reference.child("Users").child(user)

                    val firstname = firstName.text.toString().trim()
                    val lastname = lastName.text.toString().trim()
                    val city = cityFieldS.text.toString().trim()
                    val address = addressFieldS.text.toString().trim()
                    val phone = phoneField.text.toString().trim()

                    val newPost = HashMap<Any,String>()
                    newPost[firstname] = "first name"
                    newPost[lastname] = "last name"
                    newPost[city] = "city"
                    newPost[address] = "address"
                    newPost[phone] = "phone"



                    currentuserdb.setValue(newPost)

                    */
                }
                else
                    task.exception?.message?.let {
                        toast(it)
                    }
            }
    }





    override fun onStart() {
        super.onStart()

        mAuth.currentUser?.let{
            login()
        }
    }
}