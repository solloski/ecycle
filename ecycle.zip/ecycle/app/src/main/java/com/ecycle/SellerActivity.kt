package com.ecycle

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import androidx.cardview.widget.CardView
import com.ecycle.AccountActivity.R
import com.ecycle.AccountActivity.RegisterActivity
import kotlinx.android.synthetic.main.activity_seller.*

class SellerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seller)

        val mainGrid = findViewById<GridLayout>(R.id.mainGrid)
    }

    fun setSingleEvent() {
        var i = 0
        while (i < mainGrid.childCount) {
            i++
            run {
                val cardView = mainGrid.getChildAt(i) as CardView

                cardView.setOnClickListener{
                    startActivity(Intent(this@SellerActivity, UploadSellerActivity::class.java))
                }


            }
        }

    }
}
